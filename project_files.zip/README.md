# Website Generator

This project is a website generator tool.

## Collaboration

This project was created in COLLABORATION WITH the **FireFks team at CAPACITI**.
